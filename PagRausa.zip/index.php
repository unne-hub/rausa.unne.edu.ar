<?php
header("Location:index.htm");
?>